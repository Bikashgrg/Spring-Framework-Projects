package com.cts.freelancer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.freelancer.bean.Admin;
import com.cts.freelancer.service.AdminLoginService;

@Controller
public class LoginController {
	
	@Autowired
	AdminLoginService adminLoginService;
	
	@RequestMapping("admin.html")
	public String getAdminLoginPage(){
		return "admin";
	}
	
	@RequestMapping("user.html")
	public String getUserLoginPage(){
		return "user";
	}
	
	@RequestMapping("adminHome.html")
	public String getAdminHomePage(){
		return "adminHome";
	}
	
	@RequestMapping("userHome.html")
	public String getUserHomePage(){
		return "userHome";
	}
	
	@RequestMapping("registerAdminPage.html")
	public String getRegisterAdminPage(){
		return "registerAdminPage";
	}
	
	@RequestMapping(value="adminLoginAuth", method=RequestMethod.POST)
	public ModelAndView adminAuthentication(@RequestParam String emailId, String password){
		
		ModelAndView modelAndView = new ModelAndView();
		boolean result = adminLoginService.authenticate(emailId, password);
	
		if(result){
			modelAndView.setViewName("adminHome");
			modelAndView.addObject("user", emailId);
		}
		else{
			modelAndView.setViewName("error");
		}
		return modelAndView;
	}
	
	@RequestMapping(value="registerAdmin",method=RequestMethod.GET)
    public ModelAndView registerAdmin(@ModelAttribute Admin admin)
    {
    	ModelAndView modelAndView=new ModelAndView();
    	boolean result=adminLoginService.registerAdmin(admin);
    	if(result)
    	{
    		modelAndView.setViewName("admin");
    		modelAndView.addObject("admin",admin);
    	}
    	else
    	modelAndView.setViewName("error");
    	return modelAndView;
    }

}
